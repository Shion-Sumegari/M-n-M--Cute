package main.java.bomberman.entities.tile;

import main.java.bomberman.graphics.Sprite;

public class WallTile extends Tile {

	public WallTile(int x, int y, Sprite sprite) {
		super(x, y, sprite);
	}

}
