package main.java.bomberman;

import main.java.bomberman.exceptions.BombermanException;
import main.java.bomberman.gui.Frame;

public class Bomberman {
	
	public static void main(String[] args) throws BombermanException {
		new Frame();
	}
}
